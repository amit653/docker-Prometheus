docker-compose -f compose.yml up -d

------------------

[root@a9ff64324bb0 csvserver]# netstat -ntlp
Active Internet connections (only servers)
Proto Recv-Q Send-Q Local Address           Foreign Address         State       PID/Program name    
tcp        0      0 127.0.0.11:39419        0.0.0.0:*               LISTEN      -                   
tcp6       0      0 :::9300                 :::*                    LISTEN      1/csvserver     --------> running on 9300

sh getcsv.sh
